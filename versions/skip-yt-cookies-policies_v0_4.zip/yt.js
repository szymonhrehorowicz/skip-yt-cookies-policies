// Script handles accept cookies policies popup on youtube webpage
let dialog = document.querySelector('#dialog');
if (dialog) {
    dialog.children['content'].children[2].children[4].children[1].children[1].click();
}
