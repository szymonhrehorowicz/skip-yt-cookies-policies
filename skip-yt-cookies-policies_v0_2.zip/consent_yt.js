// Script handles accept cookies policies webpage and redirects to yt
document.querySelector('button').click();
