document.querySelector('button').click();
